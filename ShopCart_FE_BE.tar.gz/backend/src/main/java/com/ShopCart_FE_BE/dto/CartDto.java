package com.ShopCart_FE_BE.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartDto {
    private Long id;
    private Integer quantity;
    private BigDecimal total;
    private CartProductDto product;
}
